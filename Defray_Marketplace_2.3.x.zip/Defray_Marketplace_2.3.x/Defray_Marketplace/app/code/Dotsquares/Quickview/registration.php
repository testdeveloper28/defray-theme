<?php
/**
 * @author Dotsquares Team
 * @copyright Copyright (c) 2015 Dotsquares (http://www.dotsquares.com)
 * @package Dotsquares_Quickview
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Dotsquares_Quickview',
    __DIR__
);
