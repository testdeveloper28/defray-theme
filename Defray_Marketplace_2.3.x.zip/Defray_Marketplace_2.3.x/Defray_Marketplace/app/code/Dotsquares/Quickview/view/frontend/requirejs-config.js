var config = {
    map: {
        '*': {
            magnificPopup: 'Dotsquares_Quickview/js/jquery.magnific-popup.min',
            dotsquaresQuickview: 'Dotsquares_Quickview/js/quickview'
        }
    },
    shim: {
        magnificPopup: {
            deps: ['jquery']
        }
    }
};
