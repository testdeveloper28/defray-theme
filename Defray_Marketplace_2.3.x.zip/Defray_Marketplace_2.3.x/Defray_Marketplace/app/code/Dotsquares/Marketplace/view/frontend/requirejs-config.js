var config = {
	
	paths: {
		'dotsquares/marketplace': 'Dotsquares_Marketplace/js/owl.carousel.min',
	},   
    shim: {
        'dotsquares/marketplace': {
            deps: ['jquery']
        }
    }
};